package com.microservices.mifirstmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MifirstmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MifirstmicroserviceApplication.class, args);
	}

}
